package com.westpac;

/**
 * TODO: Fix me!
 */
public class ServiceImpl implements Service {

    private final AccountLookupService accountLookupService;
    private final LegacyService legacyService;

    public ServiceImpl(AccountLookupService accountLookupService, LegacyService legacyService) {
        this.accountLookupService = accountLookupService;
        this.legacyService = legacyService;
    }

    @Override
    public void submit(final Request request) {
            accountLookupService.lookup(request.getId(), request.getClientId(), new AccountLookupService.Callback() {
                @Override
                public void onResult(String id, String accountId) {
                    synchronized (legacyService) {
                        legacyService.execute(request, accountId);
                    }
                }
            });
    }

    @Override
    public void shutdown() {
        //Not currently used
    }
}
